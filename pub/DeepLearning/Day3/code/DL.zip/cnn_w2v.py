#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Mar  7 10:26:57 2018

@author: ssn-9
"""

       
def find_dim():
    fr=open('feature.txt','r')
    length=[]
    content=fr.read().splitlines()
    for sentence in content:
        length.append(len(sentence.split()))
    print(length)
    dim=max(length)-1
    print(dim)
    fr.close()
    return dim
    

def gen_w2v(content):
    import nltk
    from gensim.models.keyedvectors import KeyedVectors
    model = KeyedVectors.load_word2vec_format('./GoogleNews-vectors-negative300.bin.gz', binary=True, limit=20000)
    dim=find_dim()
    new_dim=dim*300
    x=[]
    y=[]
    
    for sentence in content:
        fea_vector=[]
        lab=[]
        label=sentence.split(' ', 1)[0]
        fea=sentence.split(' ', 1)[1]
        
        # converting label into vector
        if label=='relevant':
            l=1
        if label=='irrelevant':
            l=0
        lab.append(l)
        
        # converting a word into a vector using Word2Vec
        token = nltk.word_tokenize(fea)
        for word in token:
            if word in model.vocab:     #if word is available in vocabulary
                vec=model[word]
                for i in range(300):
                    fea_vector.append(vec[i])
                
        fea_vector = fea_vector + [0] * (new_dim - len(fea_vector))     # pad fea_vector with 0 upto new_dim

        x.append(fea_vector)
        y.append(lab)
    
    return x,y,new_dim
    

    
def cnn_fea_train():
    
    fr=open('feature.txt','r')
    content=fr.read().splitlines()
    x_train, y_train, new_dim = gen_w2v(content)
    fr.close()
    return x_train, y_train, new_dim



def cnn_fea_test():
    
    fr=open('feature_test.txt','r')
    content=fr.read().splitlines()
    x_test, y_test, new_dim = gen_w2v(content)
    fr.close()
    return x_test, y_test, new_dim



from keras.models import Sequential
from keras.layers.core import Dense, Dropout
from keras.layers import Conv1D, GlobalAveragePooling1D, MaxPooling1D
import keras.backend as K
import numpy as np


def cnn_test():
    x_train, y_train, new_dim= cnn_fea_train()
    x_test, y_test, new_dim = cnn_fea_test()    
        
    x_train = np.expand_dims(x_train, axis=2) # reshape (569, 30) to (569, 30, 1) 
    y_train = np.array(y_train)
    print(x_train.shape)
    print(y_train.shape)
    
    x_test = np.expand_dims(x_test, axis=2) # reshape (569, 30) to (569, 30, 1) 
    y_test = np.array(y_test)
    
    model = Sequential()
    model.add(Conv1D(16, 3, kernel_initializer='random_normal', activation='relu', input_shape=(new_dim,1)))  
    model.add(MaxPooling1D(3))
    model.add(Conv1D(16, 3, kernel_initializer='random_normal', activation='relu'))
    model.add(GlobalAveragePooling1D())
    model.add(Dropout(0.5))
    model.add(Dense(1, activation='sigmoid'))
    model.summary()
    model.compile(loss='binary_crossentropy',
              optimizer='rmsprop',
              metrics=['accuracy', f1_score, precision, recall])
    model.fit(x_train, y_train, batch_size=16, epochs=10)

    score = model.evaluate(x_train, y_train, batch_size=16)
    print ('')
    print('Training Score: ', score[0])
    print('Training Accuracy:', score[1])
    print('Training F1-measure:', score[2])
    print('Training Precision:', score[3])
    print('Training Recall:', score[4])
    print(' ')
    score = model.evaluate(x_test, y_test, batch_size=58)
    print ('')
    print('Test Score: ', score[0])
    print('Test Accuracy:', score[1])
    print('Test F1-measure:', score[2])
    print('Test Precision:', score[3])
    print('Test Recall:', score[4])

    
def metric(y_test, y_pred):
    # Count positive samples.
    c1 = K.sum(K.round(K.clip(y_test * y_pred, 0, 1)))
    c2 = K.sum(K.round(K.clip(y_pred, 0, 1)))
    c3 = K.sum(K.round(K.clip(y_test, 0, 1)))
    # If there are no true samples, fix the F1 score at 0.
    if c3 == 0:
        return 0
    return c1,c2,c3
    
def precision(y_test, y_pred):
    m=metric(y_test,y_pred)
    # How many selected items are relevant?
    precision = m[0] / m[1]
    return precision

def recall(y_test, y_pred):
    m=metric(y_test,y_pred)
    # How many relevant items are selected?
    recall = m[0] / m[2]
    return recall

def f1_score(y_test, y_pred):
    p=precision(y_test, y_pred)
    r=recall(y_test, y_pred)
    # Calculate f1_score
    f1_score = 2 * (p * r) / (p + r)
    return f1_score
