#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Jun 18 13:34:51 2018

@author: ssn-9
"""

def ext_txt():
    import glob
    import csv
    import xml.etree.ElementTree as ET
    
    fw=open('train_new.csv','w+')
    
    writer = csv.DictWriter(fw, fieldnames = ["Text", "Language"])
    writer.writeheader()
    
    
           
    path = 'HI-filt/*.xml'   
    files=glob.glob(path)
    i=1
    for file in files: 
    
        
        f=open(file,'r',encoding='utf-8')
        the_xml_string=f.read()
        texts = [content.text for content in ET.fromstring(the_xml_string).findall('comments')]
        texts= texts[0].replace("\n", " ")
        texts= texts.replace(".", " ")
        texts= texts.replace(",", " ")
        texts= texts.replace("?", " ")
        texts= texts.replace(";", " ")
        texts= texts.replace(":", " ")
        texts= texts.replace("\"", " ")
        #print (texts)
        texts=texts.lower()
        print(i)
        print (file, texts) 
        i=i+1
        writer.writerow({'Text': texts, 'Language': 'HI'})
        
        
        f.close()
        
    
    
    path = 'TA-filt/*.xml'   
    files=glob.glob(path)
    i=1
    for file in files: 
    
        
        f=open(file,'r',encoding='utf-8')
        the_xml_string=f.read()
        texts = [content.text for content in ET.fromstring(the_xml_string).findall('comments')]
        texts= texts[0].replace("\n", " ")
        texts= texts.replace(".", " ")
        texts= texts.replace(",", " ")
        texts= texts.replace("?", " ")
        texts= texts.replace(";", " ")
        texts= texts.replace(":", " ")
        texts= texts.replace("\"", " ")
        #print (texts)
        texts=texts.lower()
        print(i)
        print (file, texts) 
        i=i+1
        writer.writerow({'Text': texts, 'Language': 'TA'})
        
        f.close()

   
    fw.close()




def fea_vec_cvec():
    import pandas as pd
    import numpy as np
    from sklearn.feature_extraction.text import CountVectorizer
    
    txt = pd.read_csv('train_new.csv', usecols=['Text'])
        
    txt_lst=list(txt['Text'])
    #print (txt_lst)
    
    
    cv = CountVectorizer(min_df=2)
    train_vec=cv.fit_transform(txt_lst).toarray()
  
    print (cv)
    print (train_vec.shape)
    np.savetxt('feavec_train.csv',train_vec, delimiter=',')
    print(cv.vocabulary_)

def fea_vec_tfidf():
    import pandas as pd
    import numpy as np
    
    
    from sklearn.feature_extraction.text import TfidfVectorizer
    
    
    fw=open('bow.txt','w')
    
    txt = pd.read_csv('train_new.csv', usecols=['Text'])
        
    txt_lst=list(txt['Text'])
    #print (txt_lst)
    
    
    cv = TfidfVectorizer(min_df=1)
    train_vec=cv.fit_transform(txt_lst).toarray()
  
    print (cv)
    print (train_vec.shape)
    
    np.savetxt('feavec_tfidf_train.csv',train_vec, delimiter=',')
    
    bow=[]
    for i in cv.vocabulary_:
        bow.append(i)
    
    print (len(set(bow)))
    
    
    
    fea=' '.join(bow)
    #fea.replace(",", " ")
    fw.write(fea)
    fw.write('\n')
    fw.close()
    
    return bow




def ext_txt_test1():
    import glob
    import csv
    import xml.etree.ElementTree as ET
    
    fw=open('test1.csv','w')
    
    writer = csv.DictWriter(fw, fieldnames = ["File Name", "Text", "Label"])
    writer.writeheader()
    
    path = 'TEST/*.xml'   
    files=glob.glob(path)
    i=1
    for file in files: 
                
        f=open(file,'r',encoding='utf-8')
        the_xml_string=f.read()
        texts = [content.text for content in ET.fromstring(the_xml_string).findall('comments')]
        texts= texts[0].replace("\n", " ")
        texts= texts.replace(".", " ")
        texts= texts.replace(",", " ")
        texts= texts.replace("?", " ")
        texts= texts.replace(";", " ")
        texts= texts.replace(":", " ")
        texts= texts.replace("\"", " ")
        #print (texts)
        texts=texts.lower()
        print(i)
        print (file, texts) 
        i=i+1
        if("HIN" in file):
            writer.writerow({'File Name':file, 'Text': texts, 'Label': 'HI'})
        else:
            writer.writerow({'File Name':file, 'Text': texts, 'Label': 'TA'})
               
        
        f.close()
      
    
    fw.close()

def fea_vec_tfidf_test1():
    import pandas as pd
    import numpy as np
    
    #from sklearn.feature_extraction.text import CountVectorizer
    from sklearn.feature_extraction.text import TfidfVectorizer
    
    
    bow=fea_vec_tfidf()
    print(len(bow))
    
    txt = pd.read_csv('test1.csv', usecols=['Text'])
        
    txt_lst=list(txt['Text'])
    
    cv = TfidfVectorizer(vocabulary = bow, min_df=1)
    test1_vec=cv.fit_transform(txt_lst).toarray()
  
    print (cv)
    print (test1_vec.shape)
    #np.savetxt('feavec_train.csv',train_vec, delimiter=',')
    np.savetxt('feavec_tfidf_test1.csv',test1_vec, delimiter=',')    


def classify_tfidf_mlp():
    
    
    from sklearn.neural_network import MLPClassifier
    from sklearn.metrics import accuracy_score
    
    import pandas as pd
    import numpy as np
    from sklearn.model_selection import cross_val_score
    lang = pd.read_csv('train_new.csv', usecols=['Language'])
        
    train_target=list(lang['Language'])
    
    file = pd.read_csv('test1.csv', usecols=['File Name'])
        
    filename=list(file['File Name'])
        
    lab = pd.read_csv('test1.csv', usecols=['Label'])
        
    label=list(lab['Label'])
    
    fw=open('result.txt','w')
    
        
    #train_vec = np.genfromtxt('feavec_train.csv', delimiter=',')
    train_vec = np.genfromtxt('feavec_tfidf_train.csv', delimiter=',')
    test1_vec = np.genfromtxt('feavec_tfidf_test1.csv', delimiter=',')
    
    MLPclf = MLPClassifier(verbose=True).fit(train_vec, train_target)
    #MLPclf = MLPClassifier(max_iter=200).fit(train_vec, train_target)
    scores = cross_val_score(MLPclf, train_vec, train_target, cv=5)
    #print('MLP : ', scores)
    print(scores.mean())
    
    test_label=MLPclf.predict(test1_vec)
    score = accuracy_score(label, test_label)
    print("Test Accuracy: ", score)
    
    
    for i in range(0,len(filename)):
        
        fw.write(filename[i])
        fw.write("\t")
        fw.write(test_label[i])
        fw.write("\n")
    
    fw.close()


def classi():
    
    from sklearn.naive_bayes import MultinomialNB 
    from sklearn.neural_network import MLPClassifier
    from sklearn.naive_bayes import GaussianNB
    from sklearn import tree
    from sklearn.ensemble import RandomForestClassifier
    from sklearn.ensemble import AdaBoostClassifier
    from sklearn import svm
    from sklearn.linear_model import SGDClassifier
    from sklearn.ensemble import VotingClassifier
    
    import pandas as pd
    import numpy as np
    from sklearn.model_selection import cross_val_score
    lang = pd.read_csv('train_new.csv', usecols=['Language'])
        
    train_target=list(lang['Language'])
    print(set(train_target))
    
    
    train_vec = np.genfromtxt('feavec_train.csv', delimiter=',')
    #train_vec = np.genfromtxt('feavec_tfidf_train.csv', delimiter=',')
    
    
    MNBclf = MultinomialNB().fit(train_vec, train_target)
    scores = cross_val_score(MNBclf, train_vec, train_target, cv=5)
    print('MNB : ', scores)
    print(scores.mean())

    SVMclf = svm.SVC(C=1000000, kernel='rbf',gamma=0.1).fit(train_vec, train_target)
   
    scores = cross_val_score(SVMclf, train_vec, train_target, cv=5)
    print('SVM : ', scores)
    print(scores.mean())

  
    SGDclf = SGDClassifier().fit(train_vec, train_target)
    
    scores = cross_val_score(SGDclf, train_vec, train_target, cv=5)
    print('SGD : ', scores)
    print(scores.mean())
   
    MLPclf = MLPClassifier().fit(train_vec, train_target)
    #print(clf)
    scores = cross_val_score(MLPclf, train_vec, train_target, cv=5)
    print('MLP : ', scores)
    print(scores.mean())
        
    GNBclf = GaussianNB().fit(train_vec, train_target)
    #print(clf)
    scores = cross_val_score(GNBclf, train_vec, train_target, cv=5)
    print('GNB : ', scores)
    print(scores.mean())
    
    DTclf = tree.DecisionTreeClassifier().fit(train_vec, train_target)
    #print(clf)
    scores = cross_val_score(DTclf, train_vec, train_target, cv=5)
    print('DT : ', scores)
    print(scores.mean())
    
    RFclf = RandomForestClassifier().fit(train_vec, train_target)
    #print(clf)
    scores = cross_val_score(RFclf, train_vec, train_target, cv=5)
    print('RF : ', scores)
    print(scores.mean())
           
    ABclf = AdaBoostClassifier().fit(train_vec, train_target)
    
    scores = cross_val_score(ABclf, train_vec, train_target, cv=5)
    print('AB : ', scores)
    print(scores.mean())
                            
    MLPclf = MLPClassifier().fit(train_vec, train_target)
    #print(clf)
    scores = cross_val_score(MLPclf, train_vec, train_target, cv=5)
    print('MLP : ', scores)
    print(scores.mean())
    
    eclf = VotingClassifier(estimators=[('mnb', MNBclf), ('sgd', SGDclf)], voting='hard')
    scores = cross_val_score(eclf, train_vec, train_target, cv=5)
    print('Voting : ', scores)
    print(scores.mean())
    
    eclf = VotingClassifier(estimators=[('mnb', MNBclf), ('sgd', SGDclf), ('mlp', MLPclf)],  weights=[2,1,2])
    scores = cross_val_score(eclf, train_vec, train_target, cv=5)
    print('Voting : ', scores)
    print(scores.mean())

def word2vec_train():
    
    from gensim.models import Word2Vec
    from gensim.models import word2vec
    import pandas as pd
    
    fw=open('train_text.txt','w')
    
    txt = pd.read_csv('train_new.csv', usecols=['Text'])
        
    txt_lst=list(txt['Text'])
    for i in txt_lst:
        fw.write(i)
        fw.write("\n")
    
    fw.close()
    
    sentences = word2vec.Text8Corpus('train_text.txt')
 
    
    model = Word2Vec(sentences, min_count=1, size=10, window=10)
    model.train(txt_lst, total_examples=len(txt_lst), epochs=10)
    model.wv.save_word2vec_format('model.txt', binary=False)
    
   
    #print(mod)
   
    vocab_size = len(model.wv.vocab)
    print(vocab_size)
    #print (model.wv[0])